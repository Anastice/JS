((c)=>{
	let $ = c.getContext('2d'),
		w = c.width = window.innerWidth,
		h = c.height = window.innerHeight,
		opts = {
			span: Math.PI*2,
			speed: Math.PI/180*2
		},
		arr = new Array(25 + 1).fill().map( (el,ind) => {
			return {
				th: (Math.PI*2)/25*ind,
			}
		}),
		width = 10;
	function draw(){
		$.fillStyle = "#222";
		$.fillRect(0,0,w,h);
		arr.forEach((el,ind)=>{
			el.th += opts.speed;
			$.beginPath();
			$.arc(500, 250, 200, 0, 2*Math.PI, false);
			$.closePath();
			$.fillStyle = "hsl("+el.th*30+",50%,50%)"
			$.fill();
			$.lineWidth = 10;
			$.strokeStyle = 'black';
			$.stroke();
			
				$.beginPath();		
				$.moveTo(500, 450);
				$.lineTo(500, 50);
				$.stroke();
				
				$.beginPath();		
				$.moveTo(300, 250);
				$.lineTo(700, 250);
				$.stroke();
				
				$.beginPath();		
				$.moveTo(355, 105);
				$.lineTo(645, 390);
				$.stroke();
				
				$.beginPath();		
				$.moveTo(500, 250);
				$.lineTo(355, 390);
				$.stroke();
				
				$.beginPath();		
				$.moveTo(500, 250);
				$.lineTo(645, 105);
				$.stroke();
				
			
// $.beginPath();		
// $.moveTo(500, 250);
// $.lineTo(500, 50);
// $.stroke();
// $.beginPath();		
// $.moveTo(500, 250);
// $.lineTo(500, 50);
// $.stroke();
// $.beginPath();		
// $.moveTo(500, 250);
// $.lineTo(500, 50);
// $.stroke();
// $.beginPath();		
// $.moveTo(500, 250);
// $.lineTo(500, 50);
// $.stroke();
		})
		requestAnimationFrame(draw)
	}
	draw();
})(c)